package com.shoppingsite.seller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shoppingsiteproductupload.dao.CustomerInfoDao;
import com.shoppingsiteproductupload.dao.VendorDao;

/**
 * Servlet implementation class SellerPlaceOrder
 */
@WebServlet("/SellerPlaceOrder")
public class SellerPlaceOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SellerPlaceOrder() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType("text/html");  
	    PrintWriter out = response.getWriter();
	    
		String id=request.getParameter("productId");
		
		
		int i =VendorDao.updateProductPlace(id);
		
		if(i>0)
		{
			
			
			System.out.println("Sucess Check your database data insert successfully");
			
		request.getRequestDispatcher("JSP/sellerHomepage.jsp").include(request, response);  
	    	
		}
		else
		{
			
			System.out.println("Unable to insert!!!!");
		}
		
		
		
	}

}

package com.shoppingsite.productupload.bean;

public class AdminBean {
	
	private String name,email,mobileNumber,Otp,Password,TwitterPage,FacebookPage,InstagramPage;

	
	public String getOtp() {
		return Otp;
	}

	public void setOtp(String otp) {
		Otp = otp;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getTwitterPage() {
		return TwitterPage;
	}

	public void setTwitterPage(String twitterPage) {
		TwitterPage = twitterPage;
	}

	public String getFacebookPage() {
		return FacebookPage;
	}

	public void setFacebookPage(String facebookPage) {
		FacebookPage = facebookPage;
	}

	public String getInstagramPage() {
		return InstagramPage;
	}

	public void setInstagramPage(String instagramPage) {
		InstagramPage = instagramPage;
	}
	
	
	
	

}

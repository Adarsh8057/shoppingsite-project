package com.shoppingsite.productupload.bean;

public class UserDetails {

	private String name,password,mobile,Email,fullName,mobilenumber,pincode,hno,dateOfRegisteration,sector,Landmark,city,state,country,totalCustomer,NewCustomer,block,NewPAssword;

	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	public String getNewPAssword() {
		return NewPAssword;
	}

	public void setNewPAssword(String newPAssword) {
		NewPAssword = newPAssword;
	}

	public String getDateOfRegisteration() {
		return dateOfRegisteration;
	}

	public String getNewCustomer() {
		return NewCustomer;
	}

	public void setNewCustomer(String newCustomer) {
		NewCustomer = newCustomer;
	}

	public void setDateOfRegisteration(String dateOfRegisteration) {
		this.dateOfRegisteration = dateOfRegisteration;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getTotalCustomer() {
		return totalCustomer;
	}

	public void setTotalCustomer(String totalCustomer) {
		this.totalCustomer = totalCustomer;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getMobilenumber() {
		return mobilenumber;
	}

	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getHno() {
		return hno;
	}

	public void setHno(String hno) {
		this.hno = hno;
	}

	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public String getLandmark() {
		return Landmark;
	}

	public void setLandmark(String landmark) {
		Landmark = landmark;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	
	
}

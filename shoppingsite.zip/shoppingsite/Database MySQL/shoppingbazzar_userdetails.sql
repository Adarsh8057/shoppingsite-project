-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: shoppingbazzar
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `userdetails`
--

DROP TABLE IF EXISTS `userdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userdetails` (
  `Email` varchar(50) NOT NULL,
  `UserName` varchar(50) DEFAULT NULL,
  `Password` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `Gender` varchar(50) DEFAULT NULL,
  `FullName` varchar(50) DEFAULT NULL,
  `MobileNumber` varchar(12) DEFAULT NULL,
  `HouseNo` varchar(50) DEFAULT NULL,
  `Sector` varchar(10) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `State` varchar(50) DEFAULT NULL,
  `City` varchar(50) DEFAULT NULL,
  `Area` varchar(50) DEFAULT NULL,
  `AreaPin` varchar(10) DEFAULT NULL,
  `UserType` varchar(20) DEFAULT NULL,
  `otp` varchar(10) DEFAULT NULL,
  `BlockUnblock` varchar(10) DEFAULT 'Block',
  `VendorStatus` varchar(10) DEFAULT 'Invalid',
  `DateOfRegisteration` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userdetails`
--

LOCK TABLES `userdetails` WRITE;
/*!40000 ALTER TABLE `userdetails` DISABLE KEYS */;
INSERT INTO `userdetails` VALUES ('adarsh80@gmail.com','Adarsh Kumar','adarsh567','9565160602','male','Adarsh Kumar','78979879','78','78','7','78','78','india','789794','Customer','11683','Block','Valid','2019-10-28'),('adarshKumar@gmail.com','akashMaurya','akash1996','9565160602',NULL,'DigVijay','878787474`','77','77','India','uttar Pradesh','meerut','near union bank of India','7878778','Customer',NULL,'Block','Invalid','2019-10-28'),('akashmaurya123@gmail.com','Akash Maurya','123456','9565160602',NULL,'Ragav','789466','68','meerue','kl','lk','jkl','lk','1221',NULL,'12191','Block','Invalid','2019-10-28'),('akashmaurya821889@gmail.com','Adarsh Kumar','akash345','9565112546','male',NULL,NULL,'Krishna hostel','rajpura','india','meerut','near state bank of India','','222142','Vendor','12138','Block','Valid','2019-10-28'),('aman@yopmail.com','Aman kumar','123456','9999387333',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Customer',NULL,'Block','Invalid','2020-05-20'),('ankush123@gmail.com','ankush','123123','1234567891',NULL,'Ankush','7894562586','420','miramar','India','up','MEERUT',NULL,'250222','Customer',NULL,'Block','Invalid','2020-04-06'),('anshulbansal069@gmail.com','Anshul','123456','1236544545',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Customer','12362','Block','Invalid','2020-06-17'),('khslfds@sldghsd.com','Karuna `','123321','1233218765',NULL,'dsklgd1','98753','68','6','78','8','68','7','439583',NULL,NULL,'Block','Invalid',NULL),('parveen123@gmail.com','parveen','123123','1111222333','male',NULL,NULL,'A-45','sector-2','lawar','meerut','UP','India','250222','Vendor',NULL,'Block','Valid','2020-06-17'),('rajusaini90@gmail.com','raju saini','102030','1234569874',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Customer',NULL,'Block','Invalid','2020-06-13'),('shivamverma20@gmail.com','Shivam verma','','4569858462','male',NULL,NULL,'4562','sector 6','saini','MEERUT','up','India','250222','Vendor',NULL,'Block','Invalid','2020-08-15'),('shoppingbazar123@gmail.com','Akash Maurya','akash1996','9565160602',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Admin',NULL,'Block','Invalid',NULL),('shweta420@gmail.com','shweta','852963','1234567895',NULL,'Adarsh Kumar','379472','78','Methapur','INDIA','up ','MEERUT',NULL,'328y842','Customer',NULL,'Block','Invalid','2020-06-16'),('sourbhkumar302@gmail.com','Sourbh kumar','','7894562548','male',NULL,NULL,'4589','sector 3','miramar','MEERUT','up','India','250245','Vendor',NULL,'Block','Invalid','2020-08-15'),('vermaprashant@gmail.com','prashant verma','sinku$25','8934992110',NULL,'prashant verma','8934892110','vill -Marroi(Itahi), post-Jakkhini','rajatalab','India','Uttar Pradesh','varanasi',NULL,'221305','Customer',NULL,'Block','Invalid','2020-01-26'),('vermaprashant438@gmail.com','prashant verma','sinku@25','8934892110',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Customer',NULL,'Block','Invalid','2020-01-26'),('yoyoakash9_927@gmail.com','Akash Maurya','Akash Maurya8754123699','8218894801','male',NULL,NULL,'Krishna Hostel','rajpura','Rajpura','meerut','Uttar Pradesh','India','250001','Vendor',NULL,'Block','Valid','2019-10-28');
/*!40000 ALTER TABLE `userdetails` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-22  6:18:06
